import argparse
import sys
import os
import requests
import time
from pwn import *
from bs4 import BeautifulSoup
import json

#LOOP
#ADD LESS COMPLEX SCAN

class Color:
    BLUE = '\033[94m'
    GREEN = '\033[92m'
    YELLOW = '\033[93m'
    RED = '\033[91m'
    END = '\033[0m'


class Beautifier:
    def __init__(self, f, ts, s, headers=None, skip_empty=False):
        self.f = open(f, 'rb')
        self.target_server = ts
        self.json_object = []
        self.subnet = s
        self.headers = headers or {}
        # With -Pn every target is reported "up" even when it has no open
        # ports, which floods the board with dead IPs. When set, drop any host
        # that has no open port before uploading.
        self.skip_empty = skip_empty
        
    def parse_scan(self):
        try:
            soup = BeautifulSoup(self.f, "xml")
        except Exception as e:
            print(e)
            return
        try:
            hosts = soup.find_all('host')
        except Exception as e:
            print(e)
            return
        if hosts:
            for host in hosts:
                json_host = {}
                json_services = []
                try:
                    json_host['ip'] = host.address.get('addr')
                except:
                    json_host['ip'] = None
                try:
                    json_host['state'] = host.status.get('state')
                except:
                    json_host['state'] = None
                try:
                    json_host['hostname'] = host.hostname.get('name')
                except:
                    json_host['hostname'] = None
                try:
                    json_host['subnet'] = self.subnet
                except:
                    json_host['subnet'] = None


                try:
                    ports = host.find_all('port')
                except:
                    ports = None

                if ports:
                    for p in ports:
                        json_port = {}
                        try:
                            json_port['port'] = p.get('portid')
                        except:
                            json_port['port'] = None
                        try:
                            json_port['protocol'] = p.get('protocol')
                        except:
                            json_port['protocol'] = None
                        try:
                            json_port['state'] = p.state.get('state')
                        except:
                            json_port['state'] = None
                        try:
                            json_port['name'] = p.service.get('name')
                        except:
                            json_port['name'] = None
                        try:
                            json_port['version']  =  p.service.get('version')
                        except:
                            json_port['version']  = None
                        try:
                            json_port['script'] = p.script.get('output')
                        except:
                            json_port['script'] = None
                        json_services.append(json_port)

                json_host['services'] = json_services

                # -Pn noise filter: skip hosts with no open port.
                if self.skip_empty:
                    has_open = any((p.get('state') or '').startswith('open')
                                   for p in json_services)
                    if not has_open:
                        continue

                self.json_object.append(json_host)

    def upload_file(self):
        #change this
        print(self.target_server)
        print(json.dumps(self.json_object))
        r = requests.post('{}/box'.format(self.target_server), json=self.json_object, headers=self.headers, verify=False)
        print(r.content)


def ot_safety_interlock(args):
    """Fail-safe: refuse to scan if the OT exclude file is missing/empty.

    Returns the path to pass to --excludefile, or None to proceed with only
    the port-level ICS exclusion (requires explicit operator consent/--force).
    A stressed teammate who forgets the file must not be able to blast a PLC.
    """
    path = args.ot_exclude
    has_file = os.path.isfile(path) and os.path.getsize(path) > 0
    if has_file:
        print(Color.GREEN + "[OT] Using host exclusion file: " + path + Color.END)
        return path

    msg = ("\n" + Color.RED +
           "[OT-SAFETY] OT host exclusion file '{}' is missing or empty.\n".format(path) +
           "This network contains FRAGILE ICS/OT (ride PLCs, SCADA/HMI, BAS).\n" +
           "Without it, only ICS PORTS are excluded; OT HOSTS could still be probed on IT ports." +
           Color.END)
    print(msg)

    if args.force:
        print(Color.YELLOW + "[OT-SAFETY] --force supplied: proceeding with port-level exclusion ONLY." + Color.END)
        return None

    try:
        resp = input(Color.YELLOW + "Type 'SCAN' (all caps) to proceed anyway, anything else aborts: " + Color.END)
    except EOFError:
        resp = ""
    if resp.strip() == "SCAN":
        print(Color.YELLOW + "[OT-SAFETY] Operator override accepted (port-level exclusion only)." + Color.END)
        return None

    print(Color.RED + "[OT-SAFETY] Aborting. Create '{}' with OT IPs/CIDRs and retry.".format(path) + Color.END)
    sys.exit(1)


def main():

    banner = """
 ===========================
     ___     _____ ____  
    | \ \   / /_ _/ ___| 
 _  | |\ \ / / | |\___ \ 
| |_| | \ V /  | | ___) |
 \___/   \_/  |___|____/ 

 ===========================\n
    """
    print(Color.BLUE + banner + Color.END)
    example = 'Examples:\n\n'
    example += "$ python3 client.py -i 192.168.50.3 -p 7777 -s 192.168.50.0/24 "
    parser = argparse.ArgumentParser(formatter_class=argparse.RawDescriptionHelpFormatter, epilog=example)
    sgroup = parser.add_argument_group("Main Arguments")
    sgroup.add_argument("-i", metavar="[IP]", dest='target_ip', default=False, type=str, help="IP of collaboration server", required=True)
    sgroup.add_argument("-p", metavar="[PORT]", dest='target_port', default=7777, type=int, help="Port of collab server", required=False)
    sgroup.add_argument("-s", metavar="[VICTIM IP/HOST/SUBNET]", dest="victim_addr", default=False, type=str, help="Host name, IP or subnet of victim", required=True)
    # FIX: was store_false/default=False (a no-op). store_true makes -n actually
    # mean "skip the light wave, only run the heavy scan".
    sgroup.add_argument("-n", action='store_true', dest="heavy", default=False, help="only run heavy scan (skip the light wave)")

    otgroup = parser.add_argument_group("OT-Safety (ICS/SCADA)")
    otgroup.add_argument("--ot-exclude", dest="ot_exclude", default="ot_exclude.txt", type=str,
                         help="file of OT host IPs/CIDRs to exclude from ALL nmap probes (default: ot_exclude.txt)")
    otgroup.add_argument("--force", dest="force", action='store_true', default=False,
                         help="proceed even if the OT exclude file is missing/empty (DANGEROUS)")

    sgroup.add_argument("-Pn", "--no-ping", dest="no_ping", action='store_true', default=False,
                        help="skip host discovery (treat every target as up) so ICMP/ping-filtered hosts are still port-scanned; OT excludes still apply")

    sgroup.add_argument("--api-key", dest="api_key", default=None, type=str,
                        help="jVision API key for the access lock (or set JVIS_API_KEY env var)")
    sgroup.add_argument("--top-ports", dest="top_ports", default=1000, type=int,
                        help="scan the N most common TCP ports instead of all 65535 (default: 1000)")
    if len(sys.argv) == 1:
        parser.print_help()
        sys.exit(1)

    args = parser.parse_args()
    
    target_server = "http://{}:{}".format(args.target_ip,args.target_port)

    # Access lock: send X-API-Key if a key is provided (flag or env). Harmless
    # if the server lock is off.
    api_key = args.api_key or os.environ.get('JVIS_API_KEY')
    jvis_headers = {'X-API-Key': api_key} if api_key else {}

    # --- OT-safety interlock -------------------------------------------------
    # Full ICS/SCADA port set, verified against Nmap's ICS NSE portrules:
    #  502 modbus, 102 s7/iso-tsap, 20000 dnp3, 44818 enip, 2222 enip-io,
    #  47808 bacnet, 2404 iec-104, 1911/4911 niagara-fox, 4840 opc-ua,
    #  9600 omron-fins, 1962 pcworx, 2455 (koyo/directlogic),
    #  5094 hart-ip, 3671 knx, 34964 profinet-cm.
    ics_ports = "502,102,20000,44818,2222,47808,2404,1911,4911,4840,9600,1962,2455,5094,3671,34964"

    ot_file = ot_safety_interlock(args)

    # These exclusions apply to EVERY nmap invocation below (discovery + port
    # scans) so OT hosts/ports receive zero probes.
    excl = "--exclude-ports {}".format(ics_ports)
    if ot_file:
        excl += " --excludefile {}".format(ot_file)

    # Full-speed scanning (-T5, version+scripts). Scans the top-N common ports
    # (not all 65535) for speed. OT safety comes purely from the exclusions
    # above: fragile ICS ports are never scanned (handle those by hand) and
    # known OT hosts get zero packets.
    # -Pn mode: skip the discovery stage entirely. Instead of pinging to build
    # the host list, we write the raw target into the hosts file and let the
    # port scans run with -Pn (treat all as up). This catches hosts that drop
    # ICMP *and* have the discovery ports filtered. OT hosts stay protected:
    # --excludefile in {excl} still removes them from the port scans below.
    pn = "-Pn " if args.no_ping else ""
    if args.no_ping:
        initial_scan   = "printf '%s\\n' '{tgt}' > hosts_simple.txt".format(tgt=args.victim_addr)
        initial_scan_v = "printf '%s\\n' '{tgt}' > hosts_detailed.txt".format(tgt=args.victim_addr)
    else:
        initial_scan = "nmap -n -sn {excl} -PS80,23,443,21,22,25,3389,110,445,139,143,53,135,3306,8080,1723,111,995,993,5900,1025,587,8888 {tgt} -oG - | awk '/Up$/{{print $2}}' > hosts_simple.txt".format(excl=excl, tgt=args.victim_addr)
        initial_scan_v = "nmap -sn {excl} {tgt} -oG - | awk '/Up$/{{print $2}}' > hosts_detailed.txt".format(excl=excl, tgt=args.victim_addr)

    first_scan = "nmap -T5 {pn}-iL hosts_simple.txt {excl} -oX temp1.xml > firstscan.txt".format(pn=pn, excl=excl)
    second_scan = "nmap -T5 {pn}-iL hosts_detailed.txt -sSVC --top-ports {top} {excl} -oX temp2.xml > secondscan.txt".format(pn=pn, top=args.top_ports, excl=excl)

    
    p2 = log.progress("Connecting to JVIS server")
    try:
        request = requests.get(target_server, timeout=5, verify=False)
    except (requests.ConnectionError, requests.Timeout) as exception:
        p2.failure(Color.RED + "✘" + Color.END)
        print(Color.RED + "\nCould not connect to " + target_server + "\n")
        exit(1)
    p2.success(Color.GREEN + "✓" + Color.END)
    
    #fast host discovery
    if args.heavy is False:
        p1 = log.progress("Obtaining host list")
        #p1.status("test" + Color.END)
        try:
            os.remove('hosts_simple.txt')
        except:
            pass
        try:
            os.system(initial_scan)
        except:
            p1.failure(Color.RED + "✘" + Color.END)
            print(Color.RED + "\nScan on " + args.victim_addr + " failed\n")
            exit(1)

        filesize = os.path.getsize("hosts_simple.txt")
        if filesize == 0:
            p1.success(Color.YELLOW + "No hosts detected" + Color.END)
        else: 
            p1.success(Color.GREEN + "✓" + Color.END)



        try:
            os.remove('temp1.xml')
        except:
            pass

        try:
            os.remove('firstscan.txt')
        except:
            pass


        
        p3 = log.progress("Performing light-weight scan on " + args.victim_addr)
        try:
            os.system(first_scan)
        except:
            p3.failure(Color.RED + "✘" + Color.END)
            print(Color.RED + "\nScan on " + args.victim_addr + " failed\n")
            exit(1)

        try:
            l = open("firstscan.txt","r").read()
            print(l)
        except:
            p3.failure(Color.RED + "✘" + Color.END)
            print(Color.RED + "\nFailed to read scan\n")
            exit(1)

        p3.success(Color.GREEN + "✓" + Color.END)



        p4 = log.progress("Uploading results to jVis server")
        b = Beautifier('temp1.xml', target_server, args.victim_addr, jvis_headers, skip_empty=args.no_ping)
        #finish this
        try:
            b.parse_scan()
        except:
            p4.failure(Color.RED + "✘" + Color.END)
            print(Color.RED + "\nCould not parse file")
            exit(1)
        p4.success(Color.GREEN + "✓" + Color.END)

        p8 = log.progress("Uploading results to jVis server")
        try:
            b.upload_file()
        except:
            p8.failure(Color.RED + "✘" + Color.END)
            print(Color.RED + "\nCould not send results to " + target_server + "\n")
            exit(1)
        p8.success(Color.GREEN + "✓" + Color.END)

    #slower host discovery

    p5 = log.progress("Running heavy-weight scan")
    print("\n")
    try:
        os.remove('hosts_detailed.txt')
    except:
        pass

    os.system(initial_scan_v)

    try:
        os.remove('temp2.xml')
    except:
        pass
    
    try:
        os.remove('secondscan.txt')
    except:
        pass

    try:
        os.system(second_scan)
    except:
        p5.failure(Color.RED + "✘" + Color.END)
        print(Color.RED + "\nScan on " + args.victim_addr + " failed\n")
        exit(1)


    try:
        l = open("secondscan.txt","r").read()
        print(l)
    except:
        p5.failure(Color.RED + "✘" + Color.END)
        print(Color.RED + "\nFailed to read scan\n")
        exit(1)

    p5.success(Color.GREEN + "✓" + Color.END)


    p6 = log.progress("Parsing file")

    b = Beautifier('temp2.xml', target_server, args.victim_addr, jvis_headers, skip_empty=args.no_ping)
    #finish this
    try:
        b.parse_scan()
    except:
        p6.failure(Color.RED + "✘" + Color.END)
        print(Color.RED + "\nCould not parse file")
        exit(1)
    p6.success(Color.GREEN + "✓" + Color.END)

    p7 = log.progress("Uploading results to jVis server")
    try:
        b.upload_file()
    except:
        p7.failure(Color.RED + "✘" + Color.END)
        print(Color.RED + "\nCould not send results to " + target_server + "\n")
        exit(1)
    p7.success(Color.GREEN + "✓" + Color.END)

if __name__ == '__main__':
    main()
