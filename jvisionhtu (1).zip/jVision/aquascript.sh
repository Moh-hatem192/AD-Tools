#!/usr/bin/env bash
# jVision aquatone helper — OT-SAFE edition.
# Excludes ICS/SCADA ports from every nmap call, honours an OT host exclude
# file (--excludefile), uses a TCP-connect + rate-limited profile, and will
# NOT scan unless the OT exclude file exists (fail-safe interlock).
set -euo pipefail

# Full ICS/SCADA port set, verified against Nmap's ICS NSE portrules.
ICS_PORTS="502,102,20000,44818,2222,47808,2404,1911,4911,4840,9600,1962,2455,5094,3671,34964"
OT_EXCLUDE="${OT_EXCLUDE:-ot_exclude.txt}"   # override with: OT_EXCLUDE=/path ./aquascript.sh

read -p "Enter hostlist: " victim
read -p "Enter the IP of the jVision Server: " jvis

# --- OT-safety interlock -----------------------------------------------------
EXCL="--exclude-ports ${ICS_PORTS}"
if [[ -s "${OT_EXCLUDE}" ]]; then
    echo "[OT] Using host exclusion file: ${OT_EXCLUDE}"
    EXCL="${EXCL} --excludefile ${OT_EXCLUDE}"
else
    echo ""
    echo "[OT-SAFETY] OT host exclusion file '${OT_EXCLUDE}' is missing or empty."
    echo "This network contains FRAGILE ICS/OT. Without it, only ICS PORTS are excluded."
    if [[ "${1:-}" == "--force" ]]; then
        echo "[OT-SAFETY] --force supplied: proceeding with port-level exclusion ONLY."
    else
        read -p "Type 'SCAN' (all caps) to proceed anyway, anything else aborts: " ok || ok=""
        if [[ "${ok}" != "SCAN" ]]; then
            echo "[OT-SAFETY] Aborting. Create '${OT_EXCLUDE}' with OT IPs/CIDRs and retry."
            exit 1
        fi
        echo "[OT-SAFETY] Operator override accepted (port-level exclusion only)."
    fi
fi

# Full-speed scan; OT safety comes from the exclusions (ICS ports + OT hosts).
nmap -sn ${EXCL} -iL "$victim" -oG - | awk '/Up$/{print $2}' > aqua_hosts.txt
nmap -T5 -iL aqua_hosts.txt --top-ports 10000 ${EXCL} -oX scan.xml

read -p "hit enter to continue (make sure jvis is up)..." confirm
wget https://github.com/michenriksen/aquatone/releases/download/v1.7.0/aquatone_linux_amd64_1.7.0.zip -O aquatone.zip
mkdir -p aqua
unzip -o aquatone.zip
cat scan.xml | ./aquatone -out aqua -nmap
cd aqua
zip -r ../aquatonereport.zip *
cd ..
# Access lock: send X-API-Key if JVIS_API_KEY is set (harmless if lock is off).
KEYHDR=()
if [[ -n "${JVIS_API_KEY:-}" ]]; then KEYHDR=(-H "X-API-Key: ${JVIS_API_KEY}"); fi
curl -i -X POST "${KEYHDR[@]}" -H "Content-Type: multipart/form-data" -F 'data=@aquatonereport.zip' http://"$jvis":7777/upload
