#!/usr/bin/env bash
#
# jVision setup — verifies every dependency and installs ONLY what's missing,
# then builds + runs the server in Docker. Safe to run on a fresh CPTC attack
# box (Debian/Kali/Ubuntu). No pip --break-system-packages: Python deps come
# from apt packages.
#
# Usage:
#   ./setup.sh            # check deps, install missing, build + run server
#   ./setup.sh --deps     # check/install dependencies only (no server)
#   ./setup.sh --no-run   # install + build image, but don't start the server
#
set -euo pipefail

GREEN='\033[0;32m'; YELLOW='\033[1;33m'; RED='\033[0;31m'; NC='\033[0m'
ok()   { echo -e "${GREEN}[+]${NC} $*"; }
warn() { echo -e "${YELLOW}[!]${NC} $*"; }
err()  { echo -e "${RED}[-]${NC} $*"; }

SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
cd "$SCRIPT_DIR"

MODE="${1:-all}"

# --- sudo helper (no-op if already root) ------------------------------------
SUDO=""
if [[ "$(id -u)" -ne 0 ]]; then
    if command -v sudo >/dev/null 2>&1; then SUDO="sudo"; else
        err "Not root and sudo not found. Re-run as root."; exit 1
    fi
fi

# --- apt package installer (batched, only missing) --------------------------
# Maps a required command / python module to the apt package that provides it.
declare -a MISSING_PKGS=()

need_cmd() {   # need_cmd <command> <apt-package>
    if command -v "$1" >/dev/null 2>&1; then
        ok "$1 present"
    else
        warn "$1 missing -> will install $2"
        MISSING_PKGS+=("$2")
    fi
}

need_pymod() { # need_pymod <python module> <apt-package>
    if python3 -c "import $1" >/dev/null 2>&1; then
        ok "python3 module '$1' present"
    else
        warn "python3 module '$1' missing -> will install $2"
        MISSING_PKGS+=("$2")
    fi
}

echo "=== jVision dependency check ==="
need_cmd nmap   nmap
need_cmd curl   curl
need_cmd wget   wget
need_cmd unzip  unzip
need_cmd zip    zip
need_cmd git    git
need_cmd docker docker.io
need_cmd python3 python3

# Python libs used by jvisionclient.py (apt packages, never pip).
need_pymod requests python3-requests
need_pymod bs4      python3-bs4
need_pymod lxml     python3-lxml
need_pymod pwn      python3-pwntools

# docker compose: accept either the v2 plugin or the legacy binary.
if docker compose version >/dev/null 2>&1; then
    ok "docker compose (v2 plugin) present"
    COMPOSE="docker compose"
elif command -v docker-compose >/dev/null 2>&1; then
    ok "docker-compose (legacy) present"
    COMPOSE="docker-compose"
else
    warn "docker compose missing -> will install docker-compose"
    MISSING_PKGS+=("docker-compose")
    COMPOSE="docker-compose"
fi

# --- install whatever's missing, in one apt transaction ---------------------
if [[ ${#MISSING_PKGS[@]} -gt 0 ]]; then
    # de-dupe
    readarray -t MISSING_PKGS < <(printf '%s\n' "${MISSING_PKGS[@]}" | sort -u)
    warn "Installing: ${MISSING_PKGS[*]}"
    $SUDO apt-get update -qq
    $SUDO apt-get install -y "${MISSING_PKGS[@]}"
    ok "apt install complete"
    # re-resolve compose if we just installed it
    if docker compose version >/dev/null 2>&1; then COMPOSE="docker compose"; fi
else
    ok "All dependencies already satisfied"
fi

# --- docker daemon sanity ---------------------------------------------------
# A stale DOCKER_HOST (e.g. a non-existent podman socket) breaks the CLI.
if [[ -n "${DOCKER_HOST:-}" ]] && ! docker info >/dev/null 2>&1; then
    warn "DOCKER_HOST=$DOCKER_HOST looks broken; falling back to the default socket"
    unset DOCKER_HOST
fi

ensure_docker_running() {
    if docker info >/dev/null 2>&1; then ok "docker daemon reachable"; return; fi
    warn "docker daemon not reachable; trying to start it"
    $SUDO systemctl enable --now docker 2>/dev/null || $SUDO service docker start 2>/dev/null || true
    sleep 3
    if docker info >/dev/null 2>&1; then
        ok "docker daemon started"
    elif $SUDO docker info >/dev/null 2>&1; then
        warn "docker needs root for this user. Add yourself with:"
        warn "    sudo usermod -aG docker $USER   # then log out/in"
        warn "Using sudo for docker in this run."
        DOCKER="$SUDO docker"; COMPOSE="$SUDO $COMPOSE"
        return
    else
        err "Could not reach the docker daemon."; exit 1
    fi
}
DOCKER="docker"
ensure_docker_running

[[ "$MODE" == "--deps" ]] && { ok "Dependencies ready (--deps). Done."; exit 0; }

# --- build + run ------------------------------------------------------------
echo "=== Building jVision server image (local source) ==="
$COMPOSE build

if [[ "$MODE" == "--no-run" ]]; then
    ok "Image built (--no-run). Start later with: $COMPOSE up -d"
    exit 0
fi

echo "=== Starting jVision server on :7777 ==="
$COMPOSE up -d

echo "=== Waiting for server to answer /box ==="
for i in $(seq 1 60); do
    if curl -s -m2 http://127.0.0.1:7777/box >/dev/null 2>&1; then
        body="$(curl -s http://127.0.0.1:7777/box)"
        ok "Server up. GET /box -> ${body:-<empty>}"
        echo
        ok "jVision is ready:  http://127.0.0.1:7777/"
        echo    "    Scan (OT-safe):  python3 jvisionclient.py -i <server-ip> -s <range> --ot-safe"
        echo    "    First create ot_exclude.txt (see ot_exclude.txt.example)."
        exit 0
    fi
    sleep 1
done
err "Server did not respond on :7777 in time. Check: $COMPOSE logs"
exit 1
