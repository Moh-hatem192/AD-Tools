# jVision (OT-Safe Build) — Team Operating Guide

**Audience:** CPTC team operators
**Build:** `ot-safe-local` branch — local only, never pushed
**Context:** CPTC12 theme-park engagement. The target network contains **fragile OT/ICS** (ride PLCs, SCADA/HMI, building automation). Scanning it carelessly can crash physical equipment. This guide shows how to use jVision without doing that.

---

## 1. What jVision Is

jVision is our **recon-aggregation server**. Operators run a scanner client against target ranges; the client parses the nmap results and uploads them to a central server, where the whole team sees hosts, services, and a network map in one dashboard.

It has two pieces:

| Piece | What it is | Where it runs |
|-------|-----------|---------------|
| **Server** | Blazor web dashboard + database, in Docker | One shared instance, port **7777** |
| **Client** | `jvisionclient.py` — runs nmap, uploads results | Any box that can reach both the server and the targets |

There is also `aquascript.sh` (an aquatone web-screenshot pass) that feeds the same server.

---

## 2. Why This Build Is Different ("OT-Safe")

A normal aggressive scan (`-T5 -sSVC`) will send version and script probes to every open port. On fragile OT gear, those probes alone can **hang or reboot the device** — even if you never touch its industrial protocol port.

This build defends against that in two independent layers. **You must understand both, because they protect different things.**

| Layer | Mechanism | Protects against |
|-------|-----------|------------------|
| **Port exclusion** (automatic) | Every nmap call adds `--exclude-ports <16 ICS ports>` | Speaking industrial protocols (Modbus, S7, DNP3, BACnet…) directly to a device |
| **Host exclusion** (`ot_exclude.txt`) | Every nmap call adds `--excludefile ot_exclude.txt` | Sending **any** packet, on **any** port, to a known-fragile host |

> **Key point:** Excluding ICS *ports* does **not** make an OT host safe. That host usually also exposes a web UI, SMB, SSH, etc. on normal ports, and `-sV`/`-sC` against those can still crash it. The **only** thing that guarantees an OT host gets zero packets is putting its IP in `ot_exclude.txt`.

### The 16 excluded ICS ports
```
502, 102, 20000, 44818, 2222, 47808, 2404, 1911, 4911,
4840, 9600, 1962, 2455, 5094, 3671, 34964
```
(Modbus, S7, DNP3, EtherNet/IP, BACnet, IEC-104, Niagara Fox, OPC-UA, OMRON FINS, PCWorx, Koyo, HART-IP, KNX, PROFINET.)

---

## 3. One-Time Setup: Start the Server

Run this on the box that will host the dashboard. From the jVision folder:

```bash
cd /home/kali/psut-cptc/jVision
./setup.sh
```

`setup.sh` checks dependencies, installs only what's missing (via `apt` — never `pip`), builds the **local** image, and starts the server with `docker compose up -d`.

When it finishes, the dashboard is served on **all interfaces**, port 7777.

- **From the server box itself:** `http://127.0.0.1:7777/`
- **From any other teammate's box:** `http://<server-ip>:7777/` — use the server's real IP on the engagement VLAN (e.g. `http://10.0.0.10:7777/`), **not** `127.0.0.1`.

Find the server's IP with `ip -4 addr` (ignore the `172.x` Docker bridges).

Quick health check from the server box (empty `[]` is normal before any scan):
```bash
curl -s http://127.0.0.1:7777/box
```

> The server already listens on `0.0.0.0:7777`, so no extra config is needed to reach it from other boxes. If a teammate can't connect, it's a host firewall (allow TCP 7777) or a routing/segment issue — not the server binding.

**Useful variants**
| Command | Effect |
|---------|--------|
| `./setup.sh --deps` | Install dependencies only, don't start |
| `./setup.sh --no-run` | Build the image but don't start it |
| `docker compose up -d` | Start the server |
| `docker compose down` | Stop the server |
| `docker compose logs -f` | Watch server logs |

---

## 4. Optional: Access Lock (API Key)

By default the server is **open** (no login required) — fine inside the engagement VLAN. If you want to lock the data endpoints (`/box`, `/creds`, `/upload`, `/download`):

**On the server**, before starting:
```bash
export JVIS_API_KEY=$(openssl rand -hex 24)
echo "$JVIS_API_KEY"        # share this exact string with the team
```
Add this line under the service in `docker-compose.yml`:
```yaml
    environment:
      - JVIS_API_KEY=${JVIS_API_KEY}
```
Then:
```bash
docker compose up -d --force-recreate
```

**Clients** then pass the same key:
```bash
JVIS_API_KEY=<same-key> python3 jvisionclient.py -i <server-ip> -s <range>
```

> The key is read **once at startup**. If you change it, you must `docker compose up -d --force-recreate`.
> This is **plaintext** (no TLS) — safe inside the VLAN, but don't reuse a sensitive password as the value. If the lock is off, skip this whole section.

---

## 5. CRITICAL: Build `ot_exclude.txt` Before Scanning

`ot_exclude.txt` is the list of OT hosts that must receive **zero** packets. The scanner **refuses to run** if this file is missing or empty (a deliberate fail-safe).

Create it in the directory you run the client from. One IP or CIDR per line, bare addresses only (no comments):
```
10.10.70.0/24
192.168.50.15
```

**How to populate it:** from your passive/discovery recon. Identify OT segments and devices **first**, add them here, **then** scan.

> **Do not bypass this.** The scanner offers `--force` and a typed `SCAN` override, but both drop you to port-level exclusion only — which does not protect OT hosts on their IT-facing ports. On this engagement, treat the file as mandatory.

---

## 6. Run a Scan

From the client box:

```bash
python3 jvisionclient.py -i <server-ip> -s <target-range>
```

| Flag | Meaning |
|------|---------|
| `-i <ip>` | Collaboration server IP (**required**) — use `127.0.0.1` if on the same box |
| `-p <port>` | Server port (default `7777`) |
| `-s <target>` | Host, IP, or subnet to scan (**required**) |
| `-n` | Heavy scan only — skip the light wave |
| `--top-ports N` | Scan the top N TCP ports (default `1000`) |
| `--ot-exclude <file>` | OT exclude file (default `ot_exclude.txt`) |
| `--force` | Scan without the exclude file (**dangerous**) |
| `--api-key <key>` | Only if the access lock is enabled |

**Example (client on a different box from the server — the normal case):**
```bash
python3 jvisionclient.py -i 10.0.0.10 -s 10.129.234.0/24 --top-ports 2000
```
Use `-i 127.0.0.1` **only** when the client runs on the server box itself.

**What happens:**
1. Interlock confirms `ot_exclude.txt` exists.
2. **Light wave** — host discovery (`-sn`) + a quick `-T5` scan of live hosts → uploaded.
3. **Heavy wave** — `-T5 -sSVC --top-ports N` → uploaded.
4. Every nmap call carries both exclusions (ICS ports + OT hosts).

Watch results populate live at the dashboard (**http://<server-ip>:7777/**).

---

## 7. Use the Dashboard

Open the dashboard (**http://<server-ip>:7777/**, or `http://127.0.0.1:7777/` on the server box). For each host you can:

- See discovered services, versions, and script output.
- Set a **Zone**: `IT`, `DMZ`, or `OT`. (Hosts with no zone default to **IT**.)
- Flag **Do Not Touch** — these show a red banner and are treated as OT.

The server **auto-tags** hosts as OT when it sees an ICS port or an OT-looking hostname, but **review and correct zones manually** — the topology map and OT protections depend on them being right.

---

## 8. Export the Network Topology

jVision generates the topology as a ready-to-open **draw.io / diagrams.net** file (`.drawio`). Scan first (an empty database produces only the attacker + router node).

### Get the file
- **Dashboard:** click **"Download Topology"** → you get `topology.drawio`, or
- **CLI:**
  ```bash
  curl -s http://<server-ip>:7777/download/topology -o topology.drawio
  ```

### Render it (just open the file — no CSV import)
1. Open **https://app.diagrams.net**.
2. **File → Open From → Device** → select `topology.drawio` (or drag the file onto a blank canvas).
3. Press **Ctrl+Shift+H** to fit.

The layout is hand-positioned (no auto-layout), so it renders correctly on open:
**Attacker/VDI → router → a "Corporate Network" box** holding one **environment box per zone**, each labelled with its subnet, hosts shown as icon + **bold IP + hostname**:
- 🔴 **OT** — "OT Systems (DO NOT TOUCH)" (red)
- 🟠 **DMZ** — "DMZ / Web Environment" (amber)
- 🔵 **IT** — "IT / Active Directory Environment" (blue)
- any other zone becomes its own box; zones named **AZURE**/**CLOUD** are drawn **outside** the corp box and joined by a dashed **hybrid link**.

Icons follow each host's `Os` field (Windows / Linux / generic).

> Zones come from each host's Zone / Do-Not-Touch field (Section 7). Set those correctly **before** exporting, or every on-prem host lands in one `IT` box.

> **Export the old CSV instead?** `GET /download/diagram` still returns the legacy `diagram.csv` (Extras → Insert → Advanced → CSV…). Only `/download/topology` changed to `.drawio`.

---

## 9. Troubleshooting

| Symptom | Fix |
|---------|-----|
| `docker` errors about a bad socket | A stale `DOCKER_HOST` (dead podman socket). Run `unset DOCKER_HOST`, or just use `setup.sh` (it unsets it). Manual override: `DOCKER_HOST=unix:///var/run/docker.sock docker compose up -d` |
| Scanner aborts: "OT exclude file missing/empty" | Create `ot_exclude.txt` (Section 5). This is working as intended. |
| Server never answers on `:7777` | `docker compose logs -f` to see why; confirm the container is up with `docker compose ps` |
| `401 Unauthorized` on `/box` | Access lock is on — pass the API key (Section 4) |
| Client can't connect to server | Check `-i` is the server's reachable IP (not `127.0.0.1` from a remote box) and that `:7777` is reachable |
| `.NET`/build errors | The host has no .NET SDK by design; the build runs inside Docker. Don't install .NET on the host — rebuild with `docker compose build` |

---

## 10. Safety Cheat-Sheet (Print This)

1. **Never scan an OT segment until its hosts are in `ot_exclude.txt`.**
2. Port exclusion ≠ host protection. Only the exclude file gives a host zero packets.
3. Recon passively → identify OT → add to `ot_exclude.txt` → **then** scan.
4. Never use `--force` or type `SCAN` on this engagement unless the team lead approves.
5. Set host **Zones** in the dashboard so OT shows red and the topology is accurate.
6. All jVision work stays **local** — do not push the branch or fork the repo.
