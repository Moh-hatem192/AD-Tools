using System.Linq;
using Microsoft.AspNetCore.Builder;
using Microsoft.AspNetCore.Hosting;
using Microsoft.AspNetCore.HttpsPolicy;
using Microsoft.AspNetCore.ResponseCompression;
using Microsoft.Extensions.Configuration;
using Microsoft.Extensions.DependencyInjection;
using Microsoft.Extensions.Hosting;
using jVision.Server.Data;
using Microsoft.EntityFrameworkCore;
using jVision.Server.Models;
using Microsoft.AspNetCore.Identity;
using System.Threading.Tasks;
using jVision.Server.Hubs;
using Microsoft.Extensions.FileProviders;
using System.IO;
using Microsoft.AspNetCore.Http;
using System;
using System.Text;
using System.Security.Cryptography;

namespace jVision.Server
{
    public class Startup
    {
        public Startup(IConfiguration configuration)
        {
            Configuration = configuration;
        }

        public IConfiguration Configuration { get; }

        // This method gets called by the runtime. Use this method to add services to the container.
        // For more information on how to configure your application, visit https://go.microsoft.com/fwlink/?LinkID=398940
        public void ConfigureServices(IServiceCollection services)
        {
            services.AddSignalR();
            services.AddDbContext<JvisionServerDBContext>(options => options.UseSqlite(Configuration.GetConnectionString("SqlLiteConnection")));
            services.AddIdentity<ApplicationUser, IdentityRole>(o => {
                o.Password.RequireDigit = false;
                o.Password.RequireLowercase = false;
                o.Password.RequireUppercase = false;
                o.Password.RequireNonAlphanumeric = false;
                o.Password.RequiredLength = 5;
            }).AddEntityFrameworkStores<JvisionServerDBContext>();
            services.ConfigureApplicationCookie(options =>
            {
                options.Cookie.HttpOnly = false;
                options.Events.OnRedirectToLogin = context =>
                {
                    context.Response.StatusCode = 401;
                    return Task.CompletedTask;
                };
            });
            services.AddControllers().AddNewtonsoftJson();
            services.AddControllersWithViews();
            services.AddRazorPages();
            services.AddResponseCompression(opts =>
            {
                opts.MimeTypes = ResponseCompressionDefaults.MimeTypes.Concat(
                    new[] { "application/octet-stream" });
            });
        }

        // This method gets called by the runtime. Use this method to configure the HTTP request pipeline.
        public void Configure(IApplicationBuilder app, IWebHostEnvironment env)
        {
            var staticFolder = Path.Combine(Directory.GetCurrentDirectory(), "Aquastatic");
            if (!Directory.Exists(staticFolder))
            {
                Directory.CreateDirectory(staticFolder);
            }

            app.UseResponseCompression();
            if (env.IsDevelopment())
            {
                app.UseDeveloperExceptionPage();
                app.UseWebAssemblyDebugging();
            }
            else
            {
                app.UseExceptionHandler("/Error");
                // The default HSTS value is 30 days. You may want to change this for production scenarios, see https://aka.ms/aspnetcore-hsts.
                app.UseHsts();
            }

            //app.UseHttpsRedirection();
            app.UseBlazorFrameworkFiles();
            app.UseStaticFiles();
            app.UseStaticFiles(new StaticFileOptions()
            {
                FileProvider = new PhysicalFileProvider(Path.Combine(Directory.GetCurrentDirectory(), @"Aquastatic")),
                RequestPath = new PathString("/Aquastatic")
            });
            app.UseRouting();
            app.UseAuthentication();
            app.UseAuthorization();

            // --- jVision access lock -------------------------------------------------
            // OFF by default. When JVIS_API_KEY is set, the data endpoints require
            // EITHER a valid login cookie (browser users) OR an X-API-Key header /
            // ?api_key= (headless scanner clients). Unset key => behaves as before,
            // so nothing breaks until the team opts in.
            var apiKey = Configuration["JVIS_API_KEY"] ?? Environment.GetEnvironmentVariable("JVIS_API_KEY");
            app.Use(async (context, next) =>
            {
                if (!string.IsNullOrEmpty(apiKey))
                {
                    var path = context.Request.Path.Value ?? string.Empty;
                    bool isProtected =
                        path.StartsWith("/box", StringComparison.OrdinalIgnoreCase) ||
                        path.StartsWith("/creds", StringComparison.OrdinalIgnoreCase) ||
                        path.StartsWith("/upload", StringComparison.OrdinalIgnoreCase) ||
                        path.StartsWith("/download", StringComparison.OrdinalIgnoreCase);

                    if (isProtected)
                    {
                        bool authed = context.User?.Identity?.IsAuthenticated == true;
                        if (!authed)
                        {
                            var provided = context.Request.Headers["X-API-Key"].ToString();
                            if (string.IsNullOrEmpty(provided))
                                provided = context.Request.Query["api_key"].ToString();
                            if (!string.IsNullOrEmpty(provided) &&
                                CryptographicOperations.FixedTimeEquals(
                                    Encoding.UTF8.GetBytes(provided),
                                    Encoding.UTF8.GetBytes(apiKey)))
                            {
                                authed = true;
                            }
                        }
                        if (!authed)
                        {
                            context.Response.StatusCode = StatusCodes.Status401Unauthorized;
                            await context.Response.WriteAsync("Unauthorized: valid login or X-API-Key required.");
                            return;
                        }
                    }
                }
                await next();
            });

            app.UseEndpoints(endpoints =>
            {
                endpoints.MapRazorPages();
                endpoints.MapControllers();
                endpoints.MapHub<BoxHub>("/boxhub");
                endpoints.MapFallbackToFile("index.html");
            });
        }
    }
}
